# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
EasyFormsDemos::Application.config.secret_token = '033f6d4d0cd449ffec5287d32338dd0af164d6eec1892a4e522cb6b8182f14ecc6b873269b50261d9bd45894ca6680f6f960a2f8203c549ebb174cf8da0f0e4d'
