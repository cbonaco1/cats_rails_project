class Cat < ActiveRecord::Base
end
